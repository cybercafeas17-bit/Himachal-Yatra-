package com.himachalyatra.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density);
    }

    private GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        return d;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private void addDestination(LinearLayout parent, String name, String detail) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(14), dp(16), dp(14));
        card.setBackground(shape(Color.WHITE, 16));
        TextView title = text(name, 19, Color.rgb(31, 65, 55), true);
        TextView subtitle = text(detail, 14, Color.DKGRAY, false);
        card.addView(title);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.topMargin = dp(5);
        card.addView(subtitle, sp);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.bottomMargin = dp(12);
        parent.addView(card, cp);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.rgb(242, 247, 244));
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(20), dp(28), dp(20), dp(24));
        scroll.addView(page);

        TextView brand = text("🏔️ HIMACHAL YATRA", 24, Color.WHITE, true);
        TextView tagline = text("Explore • Plan • Travel", 14, Color.WHITE, false);
        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setPadding(dp(20), dp(24), dp(20), dp(24));
        hero.setBackground(shape(Color.rgb(27, 91, 70), 20));
        hero.addView(brand);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-1, -2);
        tp.topMargin = dp(8);
        hero.addView(tagline, tp);
        page.addView(hero);

        TextView heading = text("Discover Himachal Pradesh", 22, Color.rgb(30, 52, 43), true);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, -2);
        hp.topMargin = dp(24);
        hp.bottomMargin = dp(14);
        page.addView(heading, hp);

        addDestination(page, "Manali", "Snowy peaks, valleys and mountain adventures");
        addDestination(page, "Shimla", "Heritage streets, views and hill-station charm");
        addDestination(page, "Dharamshala", "Mountain culture and peaceful monasteries");
        addDestination(page, "Spiti Valley", "High-altitude landscapes and scenic roads");

        Button plan = new Button(this);
        plan.setText("PLAN MY TRIP");
        plan.setTextColor(Color.WHITE);
        plan.setAllCaps(false);
        plan.setTextSize(16);
        plan.setBackground(shape(Color.rgb(220, 117, 49), 14));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, dp(54));
        bp.topMargin = dp(8);
        page.addView(plan, bp);
        plan.setOnClickListener(v ->
            Toast.makeText(this, "Trip planner is coming soon!", Toast.LENGTH_LONG).show()
        );

        TextView note = text("Your Himachal journey starts here.", 13, Color.GRAY, false);
        note.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-1, -2);
        np.topMargin = dp(18);
        page.addView(note, np);

        setContentView(scroll);
    }
}
